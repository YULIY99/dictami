# Dictami Privacy Policy / Политика конфиденциальности

## English

Dictami is designed so that your speech never leaves your Mac.

- **Audio.** Recording goes to a temporary 16 kHz WAV file in the system temporary directory. It exists only for the duration of one dictation and is deleted immediately after successful insertion, cancellation, or any error. There is no recording history and no opt-in to keep recordings in this version.
- **Transcription.** Performed entirely on-device by a bundled `whisper.cpp` binary. No transcription service, no API key, no account.
- **Text refinement (optional).** If you enable it, the transcript is sent to an Ollama server **on your own machine**. The endpoint is restricted to loopback addresses (`127.0.0.1`, `localhost`, `::1`); any other host is rejected. If Ollama is unavailable, the raw transcript is used.
- **Network.** The app permits only two outbound request types: an explicit Whisper model download from the official `ggerganov/whisper.cpp` Hugging Face repository, and signed Sparkle update checks after a production update domain is configured. Nothing is uploaded.
- **Software updates.** When a production update domain is configured, Sparkle may fetch the signed appcast and a selected update archive over HTTPS. The appcast and archive are verified with Sparkle EdDSA signatures. No dictated text, audio, dictionary, history, license key, or device identifier is included in update requests.
- **Clipboard.** Used only as an insertion mechanism. When simulated paste is used, the previous clipboard contents are restored automatically unless another app changed the clipboard in the meantime. Clipboard contents are never logged.
- **Analytics / telemetry.** None. No trackers, no crash reporters, no advertising SDKs, no unique identifiers.
- **Local usage statistics.** The Statistics screen stores only daily aggregate counters (dictations, words, characters, and audio duration) in macOS `UserDefaults`. It does not retain transcript text, audio, application names, or document names. You can reset these counters at any time.
- **Logs.** A local, size-bounded log (`~/Library/Logs/Dictami/`) records events and errors. It never contains raw audio, dictated text, or clipboard contents; home-directory paths are shortened. You can set the log level to *Off*.
- **Settings.** Stored locally in macOS `UserDefaults`.
- **License and trial.** License keys and the trial start/last-seen timestamps are stored only in the device-local macOS Keychain. Ed25519 license verification is performed offline; no account, device identifier, or license server is used.
- **Personal dictionary and replacements.** Stored locally in macOS `UserDefaults` and supplied only to the on-device recognition/post-processing pipeline.
- **Text history (optional, off by default).** If you explicitly enable history, up to 100 recent transcripts are stored in `~/Library/Application Support/Dictami/history.json`. Audio is never included. You can delete individual items or clear the entire history in Settings.
- **Permissions.** Microphone (recording) and Accessibility (inserting text) are requested through standard macOS mechanisms and can be revoked at any time in System Settings; the app degrades gracefully (clipboard-only mode) without Accessibility.

## Русский

Dictami устроен так, чтобы ваша речь никогда не покидала ваш Mac.

- **Аудио.** Запись идёт во временный WAV-файл (16 кГц) в системной временной папке. Он существует только на время одной диктовки и удаляется сразу после вставки, отмены или ошибки. Истории записей нет; в этой версии нет даже настройки, позволяющей их хранить.
- **Распознавание.** Выполняется целиком на устройстве встроенным `whisper.cpp`. Без сервисов распознавания, ключей API и аккаунтов.
- **Улучшение текста (опционально).** Если вы его включили, расшифровка отправляется на сервер Ollama **на вашем же компьютере**. Разрешены только loopback-адреса (`127.0.0.1`, `localhost`, `::1`); любой другой адрес отклоняется. Если Ollama недоступен — используется исходная расшифровка.
- **Сеть.** Разрешены только два типа исходящих запросов: явная загрузка модели Whisper из официального репозитория `ggerganov/whisper.cpp` на Hugging Face и проверка подписанных обновлений Sparkle после подключения рабочего домена. Ничего не отправляется.
- **Обновления приложения.** После подключения рабочего домена Sparkle может получать по HTTPS подписанный appcast и выбранный архив обновления. Appcast и архив проверяются подписью EdDSA Sparkle. Текст диктовок, аудио, словарь, история, ключ лицензии и идентификатор устройства в запросы обновлений не включаются.
- **Буфер обмена.** Используется только как механизм вставки. При имитации ⌘V прежнее содержимое буфера автоматически восстанавливается, если его тем временем не изменило другое приложение. Содержимое буфера никогда не пишется в журнал.
- **Аналитика / телеметрия.** Отсутствуют. Ни трекеров, ни crash-репортеров, ни рекламных SDK, ни уникальных идентификаторов.
- **Локальная статистика использования.** Экран «Статистика» хранит в `UserDefaults` macOS только суммарные показатели по дням: количество диктовок, слов, символов и длительность аудио. Текст диктовок, аудио, названия приложений и документов не сохраняются. Счётчики можно сбросить в любой момент.
- **Журналы.** Локальный журнал ограниченного размера (`~/Library/Logs/Dictami/`) фиксирует события и ошибки. В нём нет аудио, текста диктовок и содержимого буфера; пути внутри домашней папки сокращаются. Уровень журнала можно выключить совсем.
- **Настройки.** Хранятся локально в `UserDefaults` macOS.
- **Лицензия и пробный период.** Ключ лицензии, время начала пробного периода и последнего запуска хранятся только в локальной связке ключей macOS. Проверка подписи Ed25519 выполняется офлайн; аккаунт, идентификатор устройства и сервер лицензий не используются.
- **Личный словарь и замены.** Хранятся локально в `UserDefaults` macOS и используются только локальным распознаванием и постобработкой.
- **История текста (опционально, по умолчанию выключена).** Если вы явно включите историю, до 100 последних текстов сохраняются в `~/Library/Application Support/Dictami/history.json`. Аудио туда никогда не попадает. Отдельные записи и всю историю можно удалить в Настройках.
- **Разрешения.** Микрофон (запись) и Универсальный доступ (вставка текста) запрашиваются стандартными средствами macOS и в любой момент отзываются в Настройках системы; без Универсального доступа приложение продолжает работать в режиме «только буфер обмена».
