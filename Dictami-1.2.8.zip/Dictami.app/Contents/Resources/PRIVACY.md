# Dictami Privacy Policy


Dictami is designed so that your speech never leaves your Mac.

- **Audio.** Recording goes to a temporary 16 kHz WAV file in the system temporary directory. It exists only for the duration of one dictation and is deleted immediately after successful insertion, cancellation, or any error. There is no recording history and no opt-in to keep recordings in this version.
- **Transcription.** Performed entirely on-device by a bundled `whisper.cpp` binary. No transcription service, no API key, no account.
- **Text refinement (optional).** If you enable it, the transcript is sent to an Ollama server **on your own machine**. The endpoint is restricted to loopback addresses (`127.0.0.1`, `localhost`, `::1`); any other host is rejected. If Ollama is unavailable, the raw transcript is used.
- **Network.** The app permits only two outbound request types: an explicit Whisper model download from the official `ggerganov/whisper.cpp` Hugging Face repository, and signed Sparkle update checks after a production update domain is configured. Nothing is uploaded.
- **Software updates.** When a production update domain is configured, Sparkle may fetch the signed appcast and a selected update archive over HTTPS. The appcast and archive are verified with Sparkle EdDSA signatures. No dictated text, audio, dictionary, history, license key, or device identifier is included in update requests.
- **Clipboard.** Used only as an insertion mechanism. When simulated paste is used, the previous clipboard contents are restored automatically unless another app changed the clipboard in the meantime. Clipboard contents are never logged.
- **Analytics / telemetry.** None. No trackers, no crash reporters, no advertising SDKs, no unique identifiers.
- **Local usage statistics.** The Statistics screen stores only daily aggregate counters (dictations, words, characters, and audio duration) in macOS `UserDefaults`. It does not retain transcript text, audio, application names, or document names. You can reset these counters at any time.
- **Logs.** A local, size-bounded log (`~/Library/Logs/Dictami/`) records events and errors. It never contains raw audio, dictated text, or clipboard contents; home-directory paths are shortened. You can set the log level to *Off*.
- **Settings.** Stored locally in macOS `UserDefaults`.
- **License and trial.** License keys and the trial start/last-seen timestamps are stored only in the device-local macOS Keychain. Ed25519 license verification is performed offline; no account, device identifier, or license server is used.
- **Personal dictionary and replacements.** Stored locally in macOS `UserDefaults` and supplied only to the on-device recognition/post-processing pipeline.
- **Text history (optional, off by default).** If you explicitly enable history, up to 100 recent transcripts are stored in `~/Library/Application Support/Dictami/history.json`. Audio is never included. You can delete individual items or clear the entire history in Settings.
- **Permissions.** Microphone (recording) and Accessibility (inserting text) are requested through standard macOS mechanisms and can be revoked at any time in System Settings; the app degrades gracefully (clipboard-only mode) without Accessibility.

